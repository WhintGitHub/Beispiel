import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import org.apache.poi.util.IOUtils;
import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;




def Message processData(Message message) 
{
    ByteArrayOutputStream baos = new ByteArrayOutputStream();  
	def messageLog = messageLogFactory.getMessageLog(message);
	def body=  message.getBody();
	
    InputStream is = new ByteArrayInputStream(body.getBytes());
    def destDir = "UnzipDir";
     byte[] buffer = new byte[1024];
     Map<String, InputStream> fileEntries = new HashMap <String, InputStream>();
        try {
            ZipInputStream zis = new ZipInputStream(is);
            ZipEntry ze = zis.getNextEntry();
            while(ze != null){ 
                String fileName = ze.getName();
                
                String str1 = "<FileName>";
                String str2 = str1.concat(fileName).concat("</FileName>");
                
               if (fileName.endsWith(".iflw")){
               ByteArrayOutputStream out = new ByteArrayOutputStream();
	    	   IOUtils.copy(zis, out);
	    	   
	    	   
	    	   ByteArrayOutputStream realOutput = new ByteArrayOutputStream();
	    		    DataOutputStream dout = new DataOutputStream(realOutput);
	    		    dout.writeBytes(str2);
	    		    dout.close();
	    		    
	    		    realOutput.writeTo(out);
	    		    
	    		    realOutput.close();
	    	   
	    	      InputStream entry_is = new ByteArrayInputStream(out.toByteArray());
	    	    //InputStream entry_is = new ByteArrayInputStream(realOutput.toByteArray());
     
                   File newFile = new File(destDir + File.separator + fileName);
                
                new File(newFile.getParent()).mkdirs();
 
 
                int len;
                while ((len = entry_is.read(buffer)) > 0) {
                 baos.write(buffer, 0, len);
                }
                
                baos.close();
                //close this ZipEntry
                }
                zis.closeEntry();
                ze = zis.getNextEntry();
     
            }
            //close last ZipEntry
            zis.closeEntry();
            zis.close();
          
            
         
        } catch (IOException e) {
            e.printStackTrace();
        }
     

        
        String source = baos.toString("UTF-8");
        
        //Removed unnecessary <?xml version="1.0" encoding="UTF-8"?>
        String source1 = source.substring(source.indexOf('<bpmn2:'))
        String XML = '''<?xml version="1.0" encoding="UTF-8"?>'''
        String Str1 = source1.replace(XML,'')
        String xmlns = Str1.substring(Str1.indexOf('<bpmn2:definitions'),Str1.indexOf('<bpmn2:collaboration'))
        String Str2 = Str1.replace(xmlns,'</Item><Item>').replace('</bpmn2:definitions>','')
        String Str3 = Str2.substring(7)
        String Tag = XML.concat(xmlns.replace('bpmn2:definitions','Messages'))
        String content = Tag.concat(Str3).concat('</Item></Messages>')
    
        message.setBody(content);
        
    return message;
}


