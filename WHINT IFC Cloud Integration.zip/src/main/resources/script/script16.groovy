import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {

// MessageLog
def messageLog = messageLogFactory.getMessageLog(message);
def bodyAsString =  message.getBody(String.class);
def sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
def currDate;
use (groovy.time.TimeCategory) { 
def date = new Date()  
currDate = date;
}
def newDate = sdf.format(currDate);

messageLog.addAttachmentAsString(newDate, bodyAsString, "text/xml");

       return message;
}