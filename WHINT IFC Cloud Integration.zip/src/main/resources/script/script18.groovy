/*
 The integration developer needs to create the method processData 
 This method takes Message object of package com.sap.gateway.ip.core.customdev.util 
which includes helper methods useful for the content developer:
The methods available are:
    public java.lang.Object getBody()
	public void setBody(java.lang.Object exchangeBody)
    public java.util.Map<java.lang.String,java.lang.Object> getHeaders()
    public void setHeaders(java.util.Map<java.lang.String,java.lang.Object> exchangeHeaders)
    public void setHeader(java.lang.String name, java.lang.Object value)
    public java.util.Map<java.lang.String,java.lang.Object> getProperties()
    public void setProperties(java.util.Map<java.lang.String,java.lang.Object> exchangeProperties) 
       public void setProperty(java.lang.String name, java.lang.Object value)
 */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
       //Headers 
       def map = message.getHeaders();
       int Day = map.get("MonitoringDays").toInteger();

def sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
def fromDate;

use (groovy.time.TimeCategory) { 
def date = new Date()  
fromDate = date-Day.days }
def newDate = sdf.format(fromDate);
def fromDT = newDate.substring(0,10) + "T00:00:00"; //+ newDate.substring(11,19);

       message.setHeader("FromDateTime", fromDT);

       return message;
}